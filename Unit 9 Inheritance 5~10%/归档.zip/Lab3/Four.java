public class Four extends Three {
    public void method1() {
        System.out.println("Four1");
        super.method1();
    }

    public void method3() {
        System.out.println("Four3");
    }
}
