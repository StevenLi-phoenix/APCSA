public class Two extends One {
            public void method3() {
                System.out.println("Two3");
            }
        }
