public class Three extends One {
    public void method2() {
        System.out.println("Three2");
        method1();
    }
}
