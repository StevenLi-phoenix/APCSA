public class One {
    public void method1() {
        System.out.println("One1");
    }
}
